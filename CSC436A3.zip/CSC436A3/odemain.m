% Example of using ode45 for a 3 x 3 system of ODEs
sz = 16;

% interval of computation and initial values for the 3 unknown functions
t0 = 0; tf = 15;
y0 = [1 2 1];

% MATLAB ODE solver ode45 (you must have odefun.m)
[t, y] = ode45(@odefun, [t0 tf], y0);

% plot the 3 functions versus the independent variable
% on one single plot, using the data computed by ode45
h = plot(t, y(:, 1), 'r-', t, y(:, 2), 'g--', t, y(:, 3), 'b:');
set(h, 'Markersize', sz-2, 'LineWidth', 2);
hax = gca; set(hax, 'FontSize', sz-2, 'TickLength', [0.02 0.05])
xlabel('t', 'FontSize', sz)
ylabel('y', 'FontSize', sz)
hl = legend('first func', 'second func', 'third func', 2);
set(hl, 'FontSize', sz);
axis tight
%print -depsc odemain.m1.eps
% pause for 5 seconds
pause(5)

% plot the second function versus the first
plot(y(:, 1), y(:, 2))
xlabel('first func', 'FontSize', sz)
ylabel('second func', 'FontSize', sz)
%print -depsc odemain.m2.eps
pause(5)

% events example
opt = odeset('events', @myevents);
[t, y, te, ye, ie] = ode45(@odefun, [t0 tf], y0, opt);

% plot the 3 functions versus the independent variable
% on one single plot, using the data computed by ode45
ie1 = find(ie == 1); ie2 = find(ie == 2);

h = plot(t, y(:, 1), 'r-', t, y(:, 2), 'g--', t, y(:, 3), 'b:', ...
         te(ie1), ye(ie1, 1), 'k^', te(ie2), ye(ie2, 1), 'kv');
set(h, 'Markersize', sz-2, 'LineWidth', 2);
hax = gca; set(hax, 'FontSize', sz-2, 'TickLength', [0.02 0.05])
xlabel('t', 'FontSize', sz)
ylabel('y', 'FontSize', sz)
hl = legend('y_1', 'y_2', 'y_3', 'max y_1', 'min y_1', 2);
set(hl, 'FontSize', sz);
axis tight
%print -depsc odemain.m3.eps
