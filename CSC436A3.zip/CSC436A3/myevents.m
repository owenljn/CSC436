% function [value, isterminal, direction] = myevents(t, y)
% Locate the time when y_2 becomes 0, separately for
% the cases of increasing and decreasing directions.

function [value,isterminal,direction] = myevents(t,y)

value(1) = y(2, 1);  % Detect y_2 = 0
isterminal(1) = 0;   % do not stop the integration
		     % set to 1 for stopping
direction(1) = -1;   % -1 for decreasing direction only

value(2) = y(2, 1);  % Detect y_2 = 0
isterminal(2) = 0;   % do not stop the integration
direction(2) =  1;   % 1 for increasing direction only
